let  facetoface = document.getElementById("facetoface");
facetoface.addEventListener("click",()=>{
    window.location.href="facetoface.html";
})
let  coldcall = document.getElementById("coldcall");
console.log(coldcall);
email.addEventListener("click",()=>{
    window.location.href="coldcall.html";
})
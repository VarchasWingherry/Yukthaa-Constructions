let  coldcall = document.getElementById("coldcall");
//console.log(coldcall);
coldcall.addEventListener("click",()=>{
    window.location.href="coldcall.html";
})
let  email = document.getElementById("email");
//console.log(coldcall);
email.addEventListener("click",()=>{
    window.location.href="email.html";
})
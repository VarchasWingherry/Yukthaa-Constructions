let  factoface = document.getElementById("facetoface");
factoface.addEventListener("click",()=>{
    window.location.href="facetoface.html";
})
let  email = document.getElementById("email");
email.addEventListener("click",()=>{
    window.location.href="email.html";
})